মহাবিশ্বের মানচিত্র — v3 prototype

New in this version:
- Map layer options (street, satellite, hybrid, terrain, dark, humanitarian)
- Qibla bearing from GPS coordinates, plus live device-orientation sensor request
- Offline map file import entry point (.pmtiles/.mbtiles)
- PWA shell caching and language/favorites/panel controls

Important: this is still a prototype, not a finished native Android app.
- The offline map file selector is currently a placeholder. It does NOT yet render imported PMTiles/MBTiles, nor does it download arbitrary map regions. A real offline map feature requires an appropriate renderer, compatible licensed map data, region/zoom selection, storage management and testing.
- Downloading all map tiles globally is impractical and often prohibited by public tile-provider terms. The production app should offer regional downloads from a provider that explicitly permits offline use, or use a licensed regional map package.
- Live Qibla compass requests device orientation permission. It requires a supported sensor/browser, HTTPS in most browsers, location permission to calculate the bearing, and calibration. The code estimates heading from browser sensor events; devices differ and accuracy is not guaranteed. Confirm with a physical compass when needed.
- The owner password system in the earlier prototype is browser-local and is not a secure owner-only account. This v3 does not add a real server-side owner account. A genuinely secure owner/admin account requires backend authentication, HTTPS hosting, server-controlled updates and secret management; no single HTML/ZIP file can provide that security.
- Online map layers use third-party tile services and require internet. Satellite/terrain availability, zoom limits and licensing depend on each provider.
- A complete installable Android app requires HTTPS hosting for PWA installation or a native Android build (APK/AAB). This ZIP is not an APK.
- Cosmic objects are schematic, not to scale; multiverse is hypothetical.
